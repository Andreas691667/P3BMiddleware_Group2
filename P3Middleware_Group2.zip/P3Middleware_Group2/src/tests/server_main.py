import sys
sys.path.insert(0, './')
from src.Server.server import Server

if __name__ == "__main__":
    # start server
    server = Server()